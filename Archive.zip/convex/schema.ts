import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  tasks: defineTable({
    userId: v.id("users"),
    title: v.string(),
    status: v.union(v.literal("TODO"), v.literal("InProgress"), v.literal("Done")),
    createdAt: v.number(),
  }),
  // Autres tables ici, par exemple, messages, users, etc.
});
