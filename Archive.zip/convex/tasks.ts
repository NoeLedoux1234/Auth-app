import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Création d'une tâche
export const createTask = mutation(async (ctx, { title }: { title: string }) => {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("User must be logged in to create a task.");
  return await ctx.db.insert("tasks", {
    userId,
    title,
    status: "TODO", // Statut initial de la tâche
    createdAt: Date.now(),
  });
});

// Lecture des tâches de l'utilisateur
export const getTasks = query(async (ctx) => {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("User must be logged in to view tasks.");
  return await ctx.db
    .query("tasks")
    .filter((q) => q.eq(q.field("userId"), userId))
    .collect();
});

// Mise à jour d'une tâche
export const updateTask = mutation(
  async (ctx, { id, status }: { id: string; status: "TODO" | "InProgress" | "Done" }) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("User must be logged in to update tasks.");

    const task = await ctx.db.get(id); // Récupère la tâche par son identifiant
    
    if (task && task.userId === userId) {
      // Vérifie que la tâche appartient bien à l'utilisateur
      await ctx.db.patch(id, { status });
    } else {
      throw new Error("User can only update their own tasks.");
    }
  }
);

// Suppression d'une tâche
export const deleteTask = mutation(async (ctx, { id }: { id: string }) => {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("User must be logged in to delete tasks.");

  const task = await ctx.db.get(id); // Récupère la tâche par son identifiant
  
  if (task && task.userId === userId) {
    // Vérifie que la tâche appartient bien à l'utilisateur
    await ctx.db.delete(id);
  } else {
    throw new Error("User can only delete their own tasks.");
  }
});
